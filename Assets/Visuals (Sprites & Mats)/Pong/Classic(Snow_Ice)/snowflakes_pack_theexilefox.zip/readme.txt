Pack created by https://theexilefox.itch.io/
* Color palette has been changed and now the snowflake is available in 4 sizes

Original snowflake was sourced from:
"Winter Wonderland Pack" by Molly "Cougarmint" Willits
https://opengameart.org/content/winter-wonderland-pack